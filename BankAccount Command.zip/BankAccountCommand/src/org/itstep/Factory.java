package org.itstep;

import org.itstep.logic.AccountService;
import org.itstep.logic.AccountServiceImpl;
import org.itstep.storage.AccountMemoryStorageImpl;
import org.itstep.storage.AccountStorage;
import org.itstep.ui.AccountCashCommand;
import org.itstep.ui.AccountDeleteCommand;
import org.itstep.ui.AccountListCommand;
import org.itstep.ui.AccountSaveCommand;
import org.itstep.ui.AccountTransferCommand;
import org.itstep.ui.Command;

public class Factory {
	private Command accountDeleteCommand = null;
	public Command getAccountDeleteCommand() {
		if(accountDeleteCommand == null) {
			AccountDeleteCommand command = new AccountDeleteCommand();
			accountDeleteCommand = command;
			command.setAccountService(getAccountService());
		}
		return accountDeleteCommand;
	}

	private Command accountListCommand = null;
	public Command getAccountListCommand() {
		if(accountListCommand == null) {
			AccountListCommand command = new AccountListCommand();
			accountListCommand = command;
			command.setAccountService(getAccountService());
		}
		return accountListCommand;
	}

	private Command accountSaveCommand = null;
	public Command getAccountSaveCommand() {
		if(accountSaveCommand == null) {
			AccountSaveCommand command = new AccountSaveCommand();
			accountSaveCommand = command;
			command.setAccountService(getAccountService());
		}
		return accountSaveCommand;
	}
	private Command accountTransferCommand = null;
	public Command getAccountTransferCommand() {
		if(accountTransferCommand == null) {
			AccountTransferCommand command = new AccountTransferCommand();
			accountTransferCommand = command;
			command.setAccountService(getAccountService());
		}
		return accountTransferCommand;
	}
	private Command accountCashCommand = null;
	public Command getAccountCashCommand() {
		if(accountCashCommand == null) {
			AccountCashCommand command = new AccountCashCommand();
			accountCashCommand = command;
			command.setAccountService(getAccountService());
		}
		return accountCashCommand;
	}

	private AccountService accountService = null;
	public AccountService getAccountService() {
		if(accountService == null) {
			AccountServiceImpl service = new AccountServiceImpl();
			accountService = service;
			service.setAccountStorage(getAccountStorage());
			
		}
		return accountService;
	}

	private AccountStorage accountStorage = null;
	public AccountStorage getAccountStorage() {
		if(accountStorage == null) {
			accountStorage = new AccountMemoryStorageImpl();
		}
		return accountStorage;
	}
}

