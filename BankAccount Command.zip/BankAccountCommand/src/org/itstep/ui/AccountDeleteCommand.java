package org.itstep.ui;

public class AccountDeleteCommand extends BankAccountCommand {
	@Override
	public void exec(String[] args) {
		if (args.length == 1) {
			Integer accountnumber = Integer.valueOf(args[0]);
			getAccountService().delete(accountnumber);
			System.out.println("Счёт успешно удален");

		} else {
			System.out.println("Неверное количество аргументов!");
		}
	}
}