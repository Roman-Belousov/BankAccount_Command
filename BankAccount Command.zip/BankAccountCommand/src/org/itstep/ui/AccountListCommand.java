package org.itstep.ui;


import org.itstep.domain.Bankaccount.Bankaccount;
import org.itstep.util.List;

public class AccountListCommand extends BankAccountCommand {
	@Override
	public void exec(String[] args) {
		List<Bankaccount> bankaccounts = getAccountService().findAll();
		if(bankaccounts.size() > 0) {
			for(int i = 0; i < bankaccounts.size(); i++) 
				System.out.println(bankaccounts.get(i));
			
		} else {
			
			System.out.println("������ ������ ����");
		
		}
	}
}

