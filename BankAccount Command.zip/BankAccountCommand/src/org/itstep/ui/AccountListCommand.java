package org.itstep.ui;


import java.util.ArrayList;

import org.itstep.domain.Bankaccount.Bankaccount;

public class AccountListCommand extends BankAccountCommand {
	@Override
	public void exec(String[] args) {
		ArrayList<Bankaccount> bankaccounts = getAccountService().findAll();
		if(bankaccounts.size() > 0) {
			for(int i = 0; i < bankaccounts.size(); i++) 
				System.out.println(bankaccounts.get(i));
			
		} else {
			
			System.out.println("Список счетов пуст!");
		
		}
	}
}

