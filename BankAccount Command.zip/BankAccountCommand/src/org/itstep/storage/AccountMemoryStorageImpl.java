package org.itstep.storage;

import java.util.ArrayList;

import org.itstep.domain.Bankaccount.Bankaccount;

public class AccountMemoryStorageImpl implements AccountStorage {
	private ArrayList<Bankaccount> bankaccounts = new ArrayList<>();


	@Override
	public Integer create(Bankaccount bankaccount) {
		bankaccounts.add(bankaccount);
		return 0;
	}

	@Override
	public Bankaccount read(Integer accountnumber) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(accountnumber)) {

				return bankaccounts.get(i);
			}
		}
		return null;
	}

	@Override
	public ArrayList<Bankaccount> read() {
		return bankaccounts;
	}

	@Override
	public void update(Bankaccount bankaccount) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(bankaccount.getAccountnumber())) {
				bankaccounts.set(i, bankaccount);
				return;
			}
		}
	}

	@Override
	public void delete(Integer accountnumber) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(accountnumber)) {
				bankaccounts.remove(i);
				break;
			}
		}
	}
}
	
