package org.itstep.storage;

import org.itstep.domain.Bankaccount.Bankaccount;
import org.itstep.storage.AccountStorage;
import org.itstep.util.List;

public class AccountMemoryStorageImpl implements AccountStorage {
	private List<Bankaccount> bankaccounts = new List<>();


	@Override
	public Integer create(Bankaccount bankaccount) {
		bankaccounts.add(bankaccount);
		return 0;
	}

	@Override
	public Bankaccount read(Integer accountnumber) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(accountnumber)) {

				return bankaccounts.get(i);
			}
		}
		return null;
	}

	@Override
	public List<Bankaccount> read() {
		return bankaccounts;
	}

	@Override
	public void update(Bankaccount bankaccount) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(bankaccount.getAccountnumber())) {
				bankaccounts.set(i, bankaccount);
				return;
			}
		}
	}

	@Override
	public void delete(Integer accountnumber) {
		for (int i = 0; i < bankaccounts.size(); i++) {
			if (bankaccounts.get(i).getAccountnumber().equals(accountnumber)) {
				bankaccounts.del(i);
				break;
			}
		}
	}
}
	
