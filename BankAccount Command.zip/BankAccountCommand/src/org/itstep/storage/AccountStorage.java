package org.itstep.storage;

import org.itstep.domain.Bankaccount.Bankaccount;
import org.itstep.util.List;

public interface AccountStorage {

	Integer create(Bankaccount bankaccount);

	Bankaccount read(Integer accountnumber);

	List<Bankaccount> read();

	void update(Bankaccount bankaccount);

	void delete(Integer accountnumber);
	


}
