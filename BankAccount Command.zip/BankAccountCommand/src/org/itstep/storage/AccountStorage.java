package org.itstep.storage;

import java.util.ArrayList;

import org.itstep.domain.Bankaccount.Bankaccount;

public interface AccountStorage {

	Integer create(Bankaccount bankaccount);

	Bankaccount read(Integer accountnumber);

	ArrayList<Bankaccount> read();

	void update(Bankaccount bankaccount);

	void delete(Integer accountnumber);
	


}
