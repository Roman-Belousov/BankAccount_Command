package org.itstep.domain.Bankaccount;

public class Bankaccount {
	 public Integer accountnumber;
	private Integer accountbalance;
	private int transfersumm;

	public int getTransfersumm() {
		return transfersumm;
	}

	public void setTransfersumm(int transfersumm) {
		this.transfersumm = transfersumm;
	}

	public Integer getAccountnumber() {
		return accountnumber;

	}

	public void setAccountnumber(Integer accountnumber) {
		this.accountnumber = accountnumber;

	}

	public Integer getAccountbalance() {
		return accountbalance;

	}

	public void setAccountbalance(Integer accountbalance) {
		this.accountbalance = accountbalance;

	}

	@Override
	public String toString() {
		return "Счёт №: " + accountnumber + "  " + " сумма на счёте: " + accountbalance + "  руб.";
	}

	

}
