package org.itstep.logic;

import java.util.ArrayList;

import org.itstep.domain.Bankaccount.Bankaccount;

public interface AccountService {
	
	ArrayList<Bankaccount> findAll();

	void save(Bankaccount bankaccount);

	void delete(Integer accountnumber);
	
	void transfer(Integer accountId1, Integer accountId2, int transfersumm);
	
	void cash(Integer accountId1, int transfersumm);
}

