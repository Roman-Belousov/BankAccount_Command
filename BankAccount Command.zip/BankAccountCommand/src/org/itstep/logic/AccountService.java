package org.itstep.logic;

import org.itstep.domain.Bankaccount.Bankaccount;
import org.itstep.util.List;

public interface AccountService {
	
	List<Bankaccount> findAll();

	void save(Bankaccount bankaccount);

	void delete(Integer accountnumber);
	
	void transfer(Integer accountId1, Integer accountId2, int transfersumm);
	
	void cash(Integer accountId1, int transfersumm);
}

