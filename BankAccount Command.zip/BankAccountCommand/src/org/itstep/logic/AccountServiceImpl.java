package org.itstep.logic;

import java.util.ArrayList;

import org.itstep.domain.Bankaccount.Bankaccount;
import org.itstep.storage.AccountStorage;

public class AccountServiceImpl implements AccountService{
	private AccountStorage accountstorage;

	public void setAccountStorage(AccountStorage accountstorage) {
		this.accountstorage = accountstorage;
	}
	@Override
	public ArrayList<Bankaccount> findAll() {
		return accountstorage.read();
	}
	@Override
	public void save(Bankaccount bankaccount) {
		Bankaccount oldAccount = accountstorage.read(bankaccount.getAccountnumber());
		if (oldAccount == null) {
			accountstorage.create(bankaccount);
		} else {
			accountstorage.update(bankaccount);
		}
	}
	@Override
	public void delete(Integer accountnumber) {
		System.out.println(" ");
		accountstorage.delete(accountnumber);
	}
	@Override
	public void transfer(Integer accountId1, Integer accountId2, int transfersumm) {
		//System.out.println(" ");	
		Bankaccount bankaccount1 = accountstorage.read(accountId1);
		Bankaccount bankaccount2 = accountstorage.read(accountId2);
		if(bankaccount1 != null & bankaccount2 != null ) {
			if(bankaccount1.getAccountbalance() >= transfersumm) {
				bankaccount1.setAccountbalance(bankaccount1.getAccountbalance() - transfersumm);
				accountstorage.update(bankaccount1);
			}else {
				System.out.println(" Операция не возможна! Сумма перевода превышает баланс счета!");
				
			}
			
		} else {
			System.out.println(" Операция не возможна! В базе отсутствует один из счетов! ");
			return;
		}
		
		//System.out.println(" ");	
		Bankaccount bankaccount3 = accountstorage.read(accountId2);
		if(bankaccount3 != null) {
			if(bankaccount1.getAccountbalance() >= transfersumm) {
				bankaccount3.setAccountbalance(bankaccount3.getAccountbalance() + transfersumm);
				accountstorage.update(bankaccount3);
				System.out.println(" Операция проведена успешно!");
			}
			}
		
	}
		@Override
		public void cash(Integer accountId1, int transfersumm) {
			Bankaccount bankaccount4 = accountstorage.read(accountId1);
			if(bankaccount4 != null ) {
				if(transfersumm >= 0) {
					bankaccount4.setAccountbalance(bankaccount4.getAccountbalance() + transfersumm);
					accountstorage.update(bankaccount4);
				
					System.out.println(" Баланс успешно пополнен на сумму: " + transfersumm + " руб.");
					
				}else {
					bankaccount4.setAccountbalance(bankaccount4.getAccountbalance() -(- transfersumm));
					accountstorage.update(bankaccount4);
					System.out.println(" Выдано наличными: " + (-transfersumm) + " руб.");
				}
			} else {
				System.out.println(" Операция не возможна! В базе отсутствует данный счёт! ");
				
			}
		}
		
	}
	

